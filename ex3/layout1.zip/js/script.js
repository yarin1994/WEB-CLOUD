function initialize() {

    var articles = "";
    var my_name = "yarin Mizrahi";
    
    var my_length = my_name.length;

    for(var i=0; i<my_length; i++){

        articles += "<article></article>";
    }

    var main = document.getElementsByTagName("main")[0];

    main.innerHTML = articles;

};

function color_change(){
    

    var button = document.getElementById('change1');
    var box = document.getElementsByTagName('article');

    for(var i=0; i<5; i++){
        box[i].style.backgroundColor = "red";
    }
};

function color_change_back(){
    
    var button = document.getElementById('change2');
    var box = document.getElementsByTagName('article');

    for(var i=0; i<5; i++){
        box[i].style.backgroundColor = "purple";
    }
};

function mouseover(){
    document.getElementsByTagName('article').mouseover
}